document.addEventListener('DOMContentLoaded', () => {

    // --- Lógica para o Menu Hambúrguer ---
    const hamburger = document.querySelector('.hamburger');
    const navList = document.querySelector('.nav-list');

    if (hamburger && navList) {
        hamburger.addEventListener('click', () => {
            // Alterna a classe 'active' para mostrar/esconder o menu
            navList.classList.toggle('active');
            // Adiciona uma animação ao ícone do hambúrguer
            hamburger.classList.toggle('active');
        });

        // Fecha o menu ao clicar em um link (em telas móveis)
        document.querySelectorAll('.nav-list li a').forEach(link => {
            link.addEventListener('click', () => {
                if (navList.classList.contains('active')) {
                    navList.classList.remove('active');
                    hamburger.classList.remove('active');
                }
            });
        });
    }

    // --- Lógica para Rolagem Suave (Smooth Scrolling) ---
    // --- Lógica para Rolagem Suave Personalizada (Efeito "Parallax" / Gliding) ---
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            const targetId = this.getAttribute('href');
            if (targetId === '#') return;

            const targetElement = document.querySelector(targetId);

            if (targetElement) {
                // Configurações da animação
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
                const startPosition = window.pageYOffset;
                const headerOffset = 85; // Altura do header fixo
                const distance = targetPosition - startPosition - headerOffset;
                const duration = 1500; // Duração em ms (mais lento para efeito "gliding")
                let start = null;

                // Função de Easing (easeInOutCubic - começa devagar, acelera, termina devagar)
                const easeInOutCubic = (t, b, c, d) => {
                    t /= d / 2;
                    if (t < 1) return c / 2 * t * t * t + b;
                    t -= 2;
                    return c / 2 * (t * t * t + 2) + b;
                };

                const animation = (currentTime) => {
                    if (start === null) start = currentTime;
                    const timeElapsed = currentTime - start;
                    const run = easeInOutCubic(timeElapsed, startPosition, distance, duration);

                    window.scrollTo(0, run);

                    if (timeElapsed < duration) {
                        requestAnimationFrame(animation);
                    }
                };

                requestAnimationFrame(animation);
            }
        });
    });

    // Floating Icon Logic
    const floatingMoto = document.getElementById('floating-moto');
    const logo = document.querySelector('.logo');
    const navLinks = document.querySelectorAll('.nav-list a:not(.nav-btn)');
    const headerContainer = document.querySelector('.header-container');

    if (floatingMoto && logo && headerContainer) {

        // Function to set initial position (at logo)
        const setInitialPosition = () => {
            const logoRect = logo.getBoundingClientRect();
            const containerRect = headerContainer.getBoundingClientRect();

            // Position relative to header container
            // We want it to the right of the logo text
            // logoRect.width includes the text and the image

            // Calculate left position: Logo Left relative to container + Logo Width + Gap
            const initialLeft = (logoRect.left - containerRect.left) + logoRect.width + 10;

            // Calculate top position: Logo Top relative to container + (Logo Height / 2) - (Icon Height / 2)
            const initialTop = (logoRect.top - containerRect.top) + (logoRect.height / 2) - (50 / 2);

            floatingMoto.style.width = '50px';
            floatingMoto.style.height = '50px';
            floatingMoto.style.top = `${initialTop}px`;
            floatingMoto.style.left = `${initialLeft}px`;
            floatingMoto.style.opacity = '1';
        };

        // Initialize position
        // Small delay to ensure layout is stable
        setTimeout(setInitialPosition, 100);

        // Update on resize
        window.addEventListener('resize', setInitialPosition);

        // Hover effects for Nav Links
        navLinks.forEach(link => {
            link.addEventListener('mouseenter', () => {
                const linkRect = link.getBoundingClientRect();
                const containerRect = headerContainer.getBoundingClientRect();

                // Nav icon size: 25px (increased again as requested)
                // Padding left was 30px
                // Position: left: 0, top: 50%

                const targetTop = linkRect.top - containerRect.top + (linkRect.height / 2) - (25 / 2); // Center vertically, 25px height
                const targetLeft = (linkRect.left - containerRect.left); // Position at start of padding (0 offset)

                floatingMoto.style.width = '25px';
                floatingMoto.style.height = '25px';
                floatingMoto.style.top = `${targetTop}px`;
                floatingMoto.style.left = `${targetLeft}px`;
            });
        });

        // Return to logo when leaving the nav list area
        const navList = document.querySelector('.nav-list');
        if (navList) {
            navList.addEventListener('mouseleave', () => {
                setInitialPosition();
            });
        }
    }

    // --- Lógica para o Formulário de Contato ---
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function (e) {
            e.preventDefault(); // Impede o recarregamento da página
            alert('Obrigado! Sua mensagem foi enviada. Entraremos em contato em breve.');
            contactForm.reset(); // Limpa os campos do formulário
        });
    }

    // Social Speed Dial Delay Logic
    const socialContainer = document.querySelector('.social-float-container');
    let socialTimeout;

    if (socialContainer) {
        socialContainer.addEventListener('mouseenter', () => {
            clearTimeout(socialTimeout);
            socialContainer.classList.add('active');
        });

        socialContainer.addEventListener('mouseleave', () => {
            socialTimeout = setTimeout(() => {
                socialContainer.classList.remove('active');
            }, 2000);
        });
    }

});

// Handle Row Hover (Open on Hover)
function handleRowHover(row) {
    if (!row.classList.contains('active')) {
        toggleSubOptions(row);
    }
}

// Toggle Sub-options Function (Global Scope)
function toggleSubOptions(row) {
    const nextRow = row.nextElementSibling;
    const icon = row.querySelector('.toggle-icon');
    const allExpandableRows = document.querySelectorAll('.expandable-row');

    // Close all other rows
    allExpandableRows.forEach(otherRow => {
        if (otherRow !== row) {
            const otherNextRow = otherRow.nextElementSibling;
            const otherIcon = otherRow.querySelector('.toggle-icon');

            otherRow.classList.remove('active');
            if (otherNextRow && otherNextRow.classList.contains('sub-options-row')) {
                otherNextRow.style.display = 'none';
            }
            if (otherIcon) {
                otherIcon.style.transform = 'rotate(0deg)';
            }
        }
    });

    // Toggle current row
    row.classList.toggle('active');
    if (nextRow && nextRow.classList.contains('sub-options-row')) {
        if (nextRow.style.display === 'none' || nextRow.style.display === '') {
            nextRow.style.display = 'grid'; // Changed from table-row to grid to match CSS
            icon.style.transform = 'rotate(180deg)';
        } else {
            nextRow.style.display = 'none';
            icon.style.transform = 'rotate(0deg)';
        }
    }
}

// WhatsApp Form Submission
// WhatsApp Form Submission (Simplified)
function sendToWhatsapp() {
    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const message = document.getElementById('message').value.trim();

    if (!name || !phone || !message) {
        alert('Por favor, preencha todos os campos (Nome, Telefone e Mensagem) antes de enviar.');
        return;
    }

    const whatsappNumber = '5538998192163';
    const text = `*Novo Contato via Site*\n\n*Nome:* ${name}\n*Telefone:* ${phone}\n*Mensagem:* ${message}`;

    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(text)}`;

    window.open(whatsappUrl, '_blank');
}